function symbolicSolutions(s)
%writeSolutions Summary of this function goes here
%   Detailed explanation goes here

fields = {'T01','T02','T03','T04','T10','T21','T32','T43', ...
    'w11','u11','w22','u22','w33','u33','w44','u44','w04','u04', ...
    'J44','detJ44','detJ44factors'};

fid = fopen('symbolic_solutions.txt','w');
for i = 1:numel(fields)
    fprintf(fid, '# %s\r\n', fields{i});
    foo = s.(fields{i});
    [rows, cols] = size(foo);
    for r = 1:rows
        for c = 1:cols
            fprintf(fid, '%40s', foo(r, c));
        end
        fprintf(fid, '\r\n');
    end
    fprintf(fid, '\r\n');
end
fclose(fid);
!notepad symbolic_solutions.txt

end

