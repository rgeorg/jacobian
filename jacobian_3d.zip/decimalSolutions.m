function [d] = decimalSolutions(s, d)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

fields = {'T01','T02','T03','T04','T10','T21','T32','T43', ...
    'w11','u11','w22','u22','w33','u33','w44','u44','w04','u04', ...
    'J44','detJ44'};

for i=1:numel(fields)
    d.(fields{i})=double(subs(s.(fields{i}),...
        [s.t1 s.t2 s.t3 s.d1 s.L3 s.d4 s.ddt_t1 s.ddt_t2 s.ddt_t3 s.ddt_d4],...
        [d.t1 d.t2 d.t3 d.d1 d.L3 d.d4 d.ddt_t1 d.ddt_t2 d.ddt_t3 d.ddt_d4]));
end

fid = fopen('decimal_solutions.txt','w');
for i = 1:numel(fields)
    fprintf(fid, '# %s\r\n', fields{i});
    foo = d.(fields{i});
    [rows, cols] = size(foo);
    for r = 1:rows
        for c = 1:cols
            fprintf(fid, '%8.3g', foo(r, c));
        end
        fprintf(fid, '\r\n');
    end
    fprintf(fid, '\r\n');
end
fclose(fid);
!notepad decimal_solutions.txt

end

