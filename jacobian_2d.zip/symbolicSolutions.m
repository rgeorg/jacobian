function symbolicSolutions(s)
%writeSolutions Summary of this function goes here
%   Detailed explanation goes here

fields = {'T01','T02','T03','T10','T21','T32', ...
    'w11','u11','w22','u22','w33','u33','w03','u03' ...
    'J33','detJ33','detJ33factors'};

fid = fopen('symbolic_solutions.txt','w');
for i = 1:numel(fields)
    fprintf(fid, '# %s\r\n', fields{i});
    foo = s.(fields{i});
    [rows, cols] = size(foo);
    for r = 1:rows
        for c = 1:cols
            fprintf(fid, '%30s', foo(r, c));
        end
        fprintf(fid, '\r\n');
    end
    fprintf(fid, '\r\n');
end
fclose(fid);
!notepad symbolic_solutions.txt

end

