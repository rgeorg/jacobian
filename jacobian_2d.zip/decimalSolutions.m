function [d] = decimalSolutions(s, d)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

fields = {'T01','T02','T03','T10','T21','T32', ...
    'w11','u11','w22','u22','w33','u33','w03','u03' ...
    'J33','detJ33'};

for i=1:numel(fields)
    d.(fields{i})=double(subs(s.(fields{i}),...
        [s.L1 s.L2 s.t1 s.t2 s.ddt_t1 s.ddt_t2],...
        [d.L1 d.L2 d.t1 d.t2 d.ddt_t1 d.ddt_t2]));
end

fid = fopen('decimal_solutions.txt','w');
for i = 1:numel(fields)
    fprintf(fid, '# %s\r\n', fields{i});
    foo = d.(fields{i});
    [rows, cols] = size(foo);
    for r = 1:rows
        for c = 1:cols
            fprintf(fid, '%8.3g', foo(r, c));
        end
        fprintf(fid, '\r\n');
    end
    fprintf(fid, '\r\n');
end
fclose(fid);
!notepad decimal_solutions.txt

end

